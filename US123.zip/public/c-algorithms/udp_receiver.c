#include "udp_receiver.h"
#ifdef _WIN32
#include <winsock2.h>
static SOCKET s=INVALID_SOCKET;
int udp_receiver_init(uint16_t port){WSADATA w;struct sockaddr_in a;if(WSAStartup(MAKEWORD(2,2),&w))return-1;s=socket(AF_INET,SOCK_DGRAM,IPPROTO_UDP);if(s==INVALID_SOCKET)return-2;a.sin_family=AF_INET;a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);a.sin_port=htons(port);return bind(s,(struct sockaddr*)&a,sizeof a)==SOCKET_ERROR?-3:0;}
int udp_receiver_read(char*b,size_t n){int r=recv(s,b,(int)n-1,0);if(r>0)b[r]=0;return r;}
void udp_receiver_close(void){if(s!=INVALID_SOCKET)closesocket(s);WSACleanup();}
#else
int udp_receiver_init(uint16_t p){(void)p;return-1;}int udp_receiver_read(char*b,size_t n){(void)b;(void)n;return-1;}void udp_receiver_close(void){}
#endif