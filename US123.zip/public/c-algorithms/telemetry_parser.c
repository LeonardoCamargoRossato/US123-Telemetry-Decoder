#include "telemetry_parser.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
static const char* key(const char*j,const char*k){char p[64];snprintf(p,sizeof p,"\"%s\"",k);return strstr(j,p);}
static int num(const char*j,const char*k,double*out){const char*p=key(j,k);char*e;if(!p)return 0;p=strchr(p,':');if(!p)return -1;p++;*out=strtod(p,&e);return e==p?-1:1;}
static int strv(const char*j,const char*k,char*out,size_t n){const char*p=key(j,k),*a,*b;if(!p)return 0;p=strchr(p,':');if(!p)return-1;a=strchr(p,'"');if(!a)return-1;b=strchr(a+1,'"');if(!b)return-1;size_t m=(size_t)(b-a-1);if(m>=n)m=n-1;memcpy(out,a+1,m);out[m]=0;return 1;}
#define N(K,D,F) do{double x;int r=num(json,K,&x);if(r==0)return(TelemetryParseResult){TELEMETRY_MISSING_FIELD,K};if(r<0)return(TelemetryParseResult){TELEMETRY_INVALID_TYPE,K};D.F=x;}while(0)
TelemetryParseResult telemetry_parse_json(const char*json,TelemetryPacket*p){double x;int r;if(!json||!p)return(TelemetryParseResult){TELEMETRY_PARSE_ERROR,"json"};memset(p,0,sizeof *p);
if(strv(json,"sat_id",p->sat_id,sizeof p->sat_id)<=0)return(TelemetryParseResult){TELEMETRY_MISSING_FIELD,"sat_id"};
if(strv(json,"ts_utc",p->timestamp,sizeof p->timestamp)<=0)return(TelemetryParseResult){TELEMETRY_MISSING_FIELD,"ts_utc"};
if(strv(json,"mode",p->mode,sizeof p->mode)<=0)return(TelemetryParseResult){TELEMETRY_MISSING_FIELD,"mode"};
r=num(json,"seq",&x);if(r<=0)return(TelemetryParseResult){r?TELEMETRY_INVALID_TYPE:TELEMETRY_MISSING_FIELD,"seq"};p->seq=(uint32_t)x;
N("lat",p->pos,lat);N("lon",p->pos,lon);N("alt_km",p->pos,alt_km);N("vel_kms",p->pos,vel_kms);N("pdop",p->pos,pdop);
num(json,"gnss_sats",&x);p->pos.gnss_sats=(uint8_t)x;N("bus_v",p->eps,bus_v);num(json,"bat_soc",&x);p->eps.bat_soc=(uint8_t)x;N("bat_t",p->eps,bat_t);N("solar_w",p->eps,solar_w);
num(json,"cpu",&x);p->obc.cpu=(uint8_t)x;num(json,"resets",&x);p->obc.resets=(uint16_t)x;strv(json,"fw",p->obc.fw,sizeof p->obc.fw);num(json,"rssi_dbm",&x);p->comm.rssi_dbm=(int16_t)x;N("snr_db",p->comm,snr_db);return(TelemetryParseResult){TELEMETRY_OK,0};}