#include "telemetry_pipeline.h"
#include "telemetry_parser.h"
#include "telemetry_validator.h"
TelemetryProcessResult telemetry_process(const char*r,TelemetryPipelineState*s,TelemetryPacket*o){TelemetryParseResult p=telemetry_parse_json(r,o);if(p.status!=TELEMETRY_OK)return(TelemetryProcessResult){p.status,p.field};TelemetryValidationResult v=telemetry_validate(o);if(v.status!=TELEMETRY_OK)return(TelemetryProcessResult){v.status,v.field};TelemetryStatus q=telemetry_sequence_check(&s->sequence,o->seq);return(TelemetryProcessResult){q,q==TELEMETRY_OK?0:"seq"};}
