#include <stdio.h>
#include <string.h>
#include "udp_receiver.h"
#include "telemetry_pipeline.h"
int main(void){char b[4096];TelemetryPipelineState s;TelemetryPacket p;memset(&s,0,sizeof s);if(udp_receiver_init(5005)){puts("UDP init failed");return 1;}puts("Listening on 127.0.0.1:5005");for(;;){int n=udp_receiver_read(b,sizeof b);if(n<=0)continue;TelemetryProcessResult r=telemetry_process(b,&s,&p);printf("\nRAW PACKET RECEIVED\nSEQ: %u\nPARSING/VALIDATION: %s\n",p.seq,r.status==TELEMETRY_OK?"OK":"REJECTED");if(r.status==TELEMETRY_OK)printf("PACKET VALID\n%s\nlat: %.4f\nlon: %.4f\nalt: %.3f km\nvel: %.3f km/s\n",p.sat_id,p.pos.lat,p.pos.lon,p.pos.alt_km,p.pos.vel_kms);else printf("status=%d field=%s\n",(int)r.status,r.field?r.field:"-");}udp_receiver_close();return 0;}