#include "telemetry_sequence.h"
TelemetryStatus telemetry_sequence_check(TelemetrySequenceState*s,uint32_t q){s->received++;if(!s->initialized){s->initialized=true;s->last_seq=q;return TELEMETRY_OK;}if(q==s->last_seq)return TELEMETRY_DUPLICATE_PACKET;if(q>s->last_seq+1){s->lost+=q-s->last_seq-1;s->last_seq=q;return TELEMETRY_SEQUENCE_GAP;}s->last_seq=q;return TELEMETRY_OK;}
